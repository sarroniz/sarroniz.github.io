# ------------------------------------------------------------
# 03_textgrid_loop.praat  -  Exercise 2
# Goal: print every interval of the "phone" tier (tier 2)
#       with its duration in ms.
# Fill in the blanks marked ___ and run the script.
# ------------------------------------------------------------

textgrid = Read from file: "../audio/F1_heed.TextGrid"
nIntervals = Get number of intervals: 2

writeInfoLine: "label", tab$, "duration_ms"

for i from 1 to ___
    label$ = Get label of interval: 2, i
    start = Get start time of interval: 2, i
    end = Get end time of interval: 2, i
    dur = (end - start) * 1000
    appendInfoLine: label$, tab$, fixed$ (dur, 0)
___

# LEVEL UP
# a) Skip the empty intervals (silence). Hint: if label$ <> "" ... endif
# b) For the vowel only, also print F1 and F2 at its midpoint.
#    Hint: you need a Formant object: To Formant (burg): 0, 5, 5500, 0.025, 50
