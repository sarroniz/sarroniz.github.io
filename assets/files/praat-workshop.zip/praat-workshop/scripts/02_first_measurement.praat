# ------------------------------------------------------------
# 02_first_measurement.praat  -  Exercise 1
# Goal: open ONE sound file and print its duration in ms.
# Fill in the blanks marked ___ and run the script.
# ------------------------------------------------------------

# 1. Open the sound (path is relative to THIS script's folder)
sound = Read from file: "../audio/F1_heed.wav"

# 2. Ask Praat for the duration (Query > Get total duration)
duration = ___

# 3. Print it in milliseconds, with no decimals
writeInfoLine: "Duration: ", fixed$ (duration * 1000, 0), " ms"

# LEVEL UP
# a) Change the file name so the script measures M1_heed.wav instead.
# b) Add a line that also prints the sampling frequency.
#    Hint: the Query menu has "Get sampling frequency".
