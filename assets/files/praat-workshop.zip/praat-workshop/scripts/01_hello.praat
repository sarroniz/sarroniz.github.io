# ------------------------------------------------------------
# 01_hello.praat  -  your very first Praat script
# Run it with Run > Run (Cmd+R on Mac, Ctrl+R on Windows)
# ------------------------------------------------------------

# Lines that start with # are comments: Praat ignores them.

writeInfoLine: "Hello, Linguistics Club!"
appendInfoLine: "You are running Praat ", praatVersion$
appendInfoLine: "2 + 2 = ", 2 + 2
