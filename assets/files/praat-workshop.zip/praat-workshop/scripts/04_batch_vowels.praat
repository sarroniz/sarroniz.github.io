# ------------------------------------------------------------
# 04_batch_vowels.praat  -  Exercise 3 (the payoff)
# For EVERY .wav file in ../audio/ (with a matching .TextGrid):
#   find the vowel on the "phone" tier and measure
#   its duration, and F1 and F2 at the vowel midpoint.
# Results are saved to vowels.csv next to this script.
# ------------------------------------------------------------

folder$ = "../audio/"
outFile$ = "vowels.csv"

# Start a fresh CSV file with a header row
# Our labels are IPA, so make sure the CSV is saved as UTF-8
# (otherwise Praat silently switches to UTF-16, which confuses Excel and R)
Text writing preferences: "UTF-8"
writeFileLine: outFile$, "file,speaker,vowel,duration_ms,F1,F2"

# Make a list of all the .wav files in the folder
fileList = Create Strings as file list: "files", folder$ + "*.wav"
nFiles = Get number of strings

for f from 1 to nFiles
    selectObject: fileList
    fileName$ = Get string: f
    name$ = fileName$ - ".wav"
    speaker$ = left$ (name$, 2)

    sound = Read from file: folder$ + fileName$
    textgrid = Read from file: folder$ + name$ + ".TextGrid"

    # Formant analysis for the whole file
    selectObject: sound
    formant = To Formant (burg): 0, 5, 5500, 0.025, 50

    # Walk through the phone tier and keep only the vowel
    selectObject: textgrid
    nIntervals = Get number of intervals: 2
    for i from 1 to nIntervals
        selectObject: textgrid
        label$ = Get label of interval: 2, i
        if label$ <> "" and label$ <> "h" and label$ <> "d"
            start = Get start time of interval: 2, i
            end = Get end time of interval: 2, i
            mid = (start + end) / 2
            selectObject: formant
            f1 = Get value at time: 1, mid, "hertz", "linear"
            f2 = Get value at time: 2, mid, "hertz", "linear"
            appendFileLine: outFile$, name$, ",", speaker$, ",", label$, ",",
            ... fixed$ ((end - start) * 1000, 0), ",", fixed$ (f1, 0), ",", fixed$ (f2, 0)
        endif
    endfor

    # Clean up before the next file
    removeObject: sound, textgrid, formant
endfor

removeObject: fileList
writeInfoLine: "Done! Measured ", nFiles, " files. Open ", outFile$, " in Excel or R."

# LEVEL UP
# a) Use a lower formant ceiling (5000 Hz) for the male speaker (M1).
#    Hint: if speaker$ = "M1" ... else ... endif
# b) Add a column with the mean F0 of the vowel.
#    Hint: To Pitch (filtered autocorrelation)... then Get mean: start, end, "Hertz"
# c) Add a form at the top so the user can choose the folder.
