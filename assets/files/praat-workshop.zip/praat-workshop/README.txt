INTRODUCTION TO PRAAT SCRIPTING - workshop materials
Linguistics Club, University of Nevada, Reno
Santiago Arróniz (sarroniz@unr.edu)

WHAT'S INSIDE
  audio/      16 short recordings of hVd words (heed, hid, head, had, hod,
              hood, who'd, hud) from two synthetic voices (F1 = female,
              M1 = male), each with a TextGrid. Tier 1 = "word", tier 2 = "phone".
              The voices were made with Praat's own speech synthesizer.
  scripts/    The exercise files. Open them from Praat; don't copy-paste
              them into a new window (see the tip below).
  solutions/  Complete versions of every exercise, including the Level up tasks.

BEFORE THE WORKSHOP
  1. Install Praat from https://www.praat.org (any recent version is fine).
  2. Unzip this folder somewhere easy to find (Desktop or Documents).

HOW TO RUN A SCRIPT
  Praat > Open Praat script...  -> choose a file in scripts/
  Then Run > Run (Cmd+R on a Mac, Ctrl+R on Windows).

  Tip: the scripts use paths like "../audio/F1_heed.wav", which Praat reads
  relative to the folder the script is saved in. If you paste code into a new,
  unsaved script window, save it in scripts/ first.

EXERCISES
  01_hello.praat               Run your first script.
  02_first_measurement.praat   Exercise 1: open a sound, print its duration.
  03_textgrid_loop.praat       Exercise 2: loop over the intervals of a TextGrid.
  04_batch_vowels.praat        Exercise 3: measure every vowel in audio/ and
                               save the results to vowels.csv.

  Each exercise has a CORE task (everyone) and LEVEL UP tasks (if you finish
  early). The LEVEL UP tasks are listed at the bottom of each script.

SOLUTIONS
  02_first_measurement_solution.praat   Exercise 1: core + level up (a, b)
  03_textgrid_loop_solution.praat       Exercise 2: core + level up (a, b)
  04_batch_vowels_solution.praat        Exercise 3: core + level up (a, b, c)

  Each solution file uses the same letters as the LEVEL UP list in the
  exercise, so you can find the answer to each task.
