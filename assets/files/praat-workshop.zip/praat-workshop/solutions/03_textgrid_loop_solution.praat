# ------------------------------------------------------------
# 03_textgrid_loop_solution.praat  -  Exercise 2, SOLUTION
# The core task first, then every LEVEL UP task (a, b),
# in the same order as in scripts/03_textgrid_loop.praat.
# Each part prints its own table in the Info window.
# ------------------------------------------------------------

textgrid = Read from file: "../audio/F1_heed.TextGrid"
nIntervals = Get number of intervals: 2

# ===== CORE: every interval of tier 2 with its duration =====
# The two blanks were: nIntervals (how far the loop goes)
# and endfor (every for needs one).
writeInfoLine: "CORE"
appendInfoLine: "label", tab$, "duration_ms"
for i from 1 to nIntervals
    label$ = Get label of interval: 2, i
    start = Get start time of interval: 2, i
    end = Get end time of interval: 2, i
    dur = (end - start) * 1000
    appendInfoLine: label$, tab$, fixed$ (dur, 0)
endfor

# ===== LEVEL UP (a): skip the empty intervals (silences) =====
# Same loop, but the printing only happens if the label is not empty.
appendInfoLine: newline$, "LEVEL UP (a)"
appendInfoLine: "label", tab$, "duration_ms"
for i from 1 to nIntervals
    label$ = Get label of interval: 2, i
    if label$ <> ""
        start = Get start time of interval: 2, i
        end = Get end time of interval: 2, i
        dur = (end - start) * 1000
        appendInfoLine: label$, tab$, fixed$ (dur, 0)
    endif
endfor

# ===== LEVEL UP (b): F1 and F2 at the vowel midpoint =====
# Formants come from the Sound, so we open it and make a Formant object.
# Because we now switch between objects, every pass of the loop
# selects the TextGrid again before asking it for labels and times.
sound = Read from file: "../audio/F1_heed.wav"
formant = To Formant (burg): 0, 5, 5500, 0.025, 50

appendInfoLine: newline$, "LEVEL UP (b)"
appendInfoLine: "label", tab$, "duration_ms", tab$, "F1", tab$, "F2"
for i from 1 to nIntervals
    selectObject: textgrid
    label$ = Get label of interval: 2, i
    if label$ <> ""
        start = Get start time of interval: 2, i
        end = Get end time of interval: 2, i
        dur$ = fixed$ ((end - start) * 1000, 0)
        if label$ = "h" or label$ = "d"
            # consonants: duration only
            appendInfoLine: label$, tab$, dur$
        else
            # the vowel: measure F1 and F2 halfway through it
            mid = (start + end) / 2
            selectObject: formant
            f1 = Get value at time: 1, mid, "hertz", "linear"
            f2 = Get value at time: 2, mid, "hertz", "linear"
            appendInfoLine: label$, tab$, dur$, tab$, fixed$ (f1, 0), tab$, fixed$ (f2, 0)
        endif
    endif
endfor
