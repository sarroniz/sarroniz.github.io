# ------------------------------------------------------------
# 02_first_measurement_solution.praat  -  Exercise 1, SOLUTION
# The core task first, then every LEVEL UP task (a, b),
# in the same order as in scripts/02_first_measurement.praat.
# ------------------------------------------------------------

# ===== CORE: print the duration of F1_heed.wav in ms =====
sound = Read from file: "../audio/F1_heed.wav"
duration = Get total duration
writeInfoLine: "Duration: ", fixed$ (duration * 1000, 0), " ms"

# ===== LEVEL UP (a): measure M1_heed.wav instead =====
# Only the file name changes. We store the new Sound in its own
# variable so we can still go back to the first one.
soundMale = Read from file: "../audio/M1_heed.wav"
durationMale = Get total duration
appendInfoLine: "Duration of M1_heed: ", fixed$ (durationMale * 1000, 0), " ms"

# ===== LEVEL UP (b): also print the sampling frequency =====
# Query > Get sampling frequency. Select the Sound you want first:
# right now M1_heed is selected, because it was the last one we opened.
selectObject: sound
fs = Get sampling frequency
appendInfoLine: "Sampling frequency: ", fs, " Hz"
