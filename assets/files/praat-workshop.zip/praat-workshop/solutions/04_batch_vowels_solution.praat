# ------------------------------------------------------------
# 04_batch_vowels_solution.praat  -  Exercise 3, SOLUTION
# This is scripts/04_batch_vowels.praat with every LEVEL UP task
# (a, b, c) added. Look for the "LEVEL UP" comments to see what
# changed. The core script itself needs no changes: just run it.
# ------------------------------------------------------------

# ===== LEVEL UP (c): a form so the user can choose the folder =====
# When you run the script, Praat shows a dialog with these two fields.
# Inside the script, the fields become the variables folder$ and output_file$.
form Measure vowels in a folder
    sentence Folder ../audio/
    word Output_file vowels_solution.csv
endform

# Our labels are IPA, so make sure the CSV is saved as UTF-8
# (otherwise Praat silently switches to UTF-16, which confuses Excel and R)
Text writing preferences: "UTF-8"

# LEVEL UP (b): one extra column for mean F0
writeFileLine: output_file$, "file,speaker,vowel,duration_ms,F1,F2,meanF0"

fileList = Create Strings as file list: "files", folder$ + "*.wav"
nFiles = Get number of strings

for f from 1 to nFiles
    selectObject: fileList
    fileName$ = Get string: f
    name$ = fileName$ - ".wav"
    speaker$ = left$ (name$, 2)

    sound = Read from file: folder$ + fileName$
    textgrid = Read from file: folder$ + name$ + ".TextGrid"

    # ===== LEVEL UP (a): formant ceiling depends on the speaker =====
    # 5500 Hz suits an average adult female voice, about 5000 Hz an
    # average adult male voice. This fixes the strange F1 of M1_whod.
    if speaker$ = "M1"
        ceiling = 5000
    else
        ceiling = 5500
    endif
    selectObject: sound
    formant = To Formant (burg): 0, 5, ceiling, 0.025, 50

    # ===== LEVEL UP (b): a Pitch object for the mean F0 =====
    # "Filtered autocorrelation" is the preferred pitch method in recent
    # Praat (6.4 and later). Older versions use the classic command instead.
    selectObject: sound
    if praatVersion >= 6444
        pitch = To Pitch (filtered autocorrelation): 0, 50, 800, 15, "no", 0.03, 0.09, 0.5, 0.055, 0.35, 0.14
    else
        pitch = To Pitch: 0, 75, 600
    endif

    selectObject: textgrid
    nIntervals = Get number of intervals: 2
    for i from 1 to nIntervals
        selectObject: textgrid
        label$ = Get label of interval: 2, i
        if label$ <> "" and label$ <> "h" and label$ <> "d"
            start = Get start time of interval: 2, i
            end = Get end time of interval: 2, i
            mid = (start + end) / 2
            selectObject: formant
            f1 = Get value at time: 1, mid, "hertz", "linear"
            f2 = Get value at time: 2, mid, "hertz", "linear"
            # LEVEL UP (b): mean F0 over the whole vowel
            selectObject: pitch
            f0 = Get mean: start, end, "Hertz"
            appendFileLine: output_file$, name$, ",", speaker$, ",", label$, ",",
            ... fixed$ ((end - start) * 1000, 0), ",", fixed$ (f1, 0), ",", fixed$ (f2, 0), ",", fixed$ (f0, 1)
        endif
    endfor

    # Clean up before the next file (the Pitch object too)
    removeObject: sound, textgrid, formant, pitch
endfor

removeObject: fileList
writeInfoLine: "Done! Measured ", nFiles, " files. Results in ", output_file$
